"""
Users exceptions
"""

from functools import wraps

from sqlalchemy.exc import DBAPIError

from src.exceptions.repository.base import BaseRepoException
from src.exceptions.repository.base import ObjectNotFoundRepoException
from src.exceptions.repository.base import CannotAddObjectRepoException
from src.exceptions.repository.base import CannotUpdateObjectRepoException
from src.exceptions.repository.base import CannotDeleteObjectRepoException


class UserRepoException(BaseRepoException):
    """Base exception for ReportRepository"""
    message = "Report repository operation failed"


class UserNotFoundException(UserRepoException):
    message = "Report not found"


class CannotAddUserException(UserRepoException):
    message = "Cannot add report"


class CannotUpdateUserException(UserRepoException):
    message = "Cannot update report"


class CannotDeleteUserException(UserRepoException):
    message = "Cannot delete report"


class UserDatabaseConnectionException(UserRepoException):
    message = "Database connection error in report repository"


def user_repo_exceptions(method):
    """
    Decorator to map generic repository exceptions to User-specific repository exceptions.
    """

    @wraps(method)
    async def wrapper(self, *args, **kwargs):
        try:
            return await method(self, *args, **kwargs)
        except ObjectNotFoundRepoException as ex:
            raise UserNotFoundException from ex
        except CannotAddObjectRepoException as ex:
            raise CannotAddUserException from ex
        except CannotUpdateObjectRepoException as ex:
            raise CannotUpdateUserException from ex
        except CannotDeleteObjectRepoException as ex:
            raise CannotDeleteUserException from ex
        except DBAPIError as ex:
            raise UserDatabaseConnectionException from ex

    return wrapper
