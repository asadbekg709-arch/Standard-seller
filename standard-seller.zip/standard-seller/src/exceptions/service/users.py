"""
User Service Exceptions
"""

from functools import wraps

from src.exceptions.service.base import BaseServiceException
from src.exceptions.repository.users import UserNotFoundException
from src.exceptions.repository.users import CannotAddUserException
from src.exceptions.repository.users import CannotDeleteUserException
from src.exceptions.repository.users import CannotUpdateUserException
from src.exceptions.repository.users import UserDatabaseConnectionException


class UserServiceException(BaseServiceException):
    """
    Base exception class for User service errors.
    """
    message = "User service operation failed"


class UserNotFound(UserServiceException):
    """
    Raised when a user is not found.
    """
    message = "User not found"

    @classmethod
    def from_repo(cls, ex: UserNotFoundException):
        return cls(f"{cls.message}: {ex}")


class UserAlreadyExists(UserServiceException):
    """
    Raised when attempting to create a user that already exists.
    """
    message = "User already exists"

    @classmethod
    def from_repo(cls, ex: CannotAddUserException):
        return cls(f"{cls.message}: {ex}")


class UserCannotUpdate(UserServiceException):
    """
    Raised when updating a user fails.
    """
    message = "Cannot update user"

    @classmethod
    def from_repo(cls, ex: CannotUpdateUserException):
        return cls(f"{cls.message}: {ex}")


class UserCannotDelete(UserServiceException):
    """
    Raised when deleting a user fails.
    """
    message = "Cannot delete user"

    @classmethod
    def from_repo(cls, ex: CannotDeleteUserException):
        return cls(f"{cls.message}: {ex}")


class UserDatabaseError(UserServiceException):
    """
    Raised when a database error occurs in the User service.
    """
    message = "Database error in user service"

    @classmethod
    def from_repo(cls, ex: UserDatabaseConnectionException):
        return cls(f"{cls.message}: {ex}")


def user_service_exceptions(method):
    """
    Decorator to map User repository exceptions to User service exceptions.
    """

    @wraps(method)
    async def wrapper(self, *args, **kwargs):
        try:
            return await method(self, *args, **kwargs)
        except UserNotFoundException as ex:
            raise UserNotFound.from_repo(ex)
        except CannotAddUserException as ex:
            raise UserAlreadyExists.from_repo(ex)
        except CannotUpdateUserException as ex:
            raise UserCannotUpdate.from_repo(ex)
        except CannotDeleteUserException as ex:
            raise UserCannotDelete.from_repo(ex)
        except UserDatabaseConnectionException as ex:
            raise UserDatabaseError.from_repo(ex)

    return wrapper
