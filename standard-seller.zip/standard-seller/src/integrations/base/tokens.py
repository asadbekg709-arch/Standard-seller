"""
Client for interacting with the IAM service.
"""

import time
import httpx
import asyncio

from src.integrations.base.errors import TokenError
from src.integrations.base.schema import AccessToken
from src.integrations.base.protocols import TokenClientConfig


class OAuthClientCredentialsTokenProvider:
    """
    Provides and caches OAuth2 access tokens using client credentials.

    :param iam: IAMSettings instance containing token endpoint configuration
    """

    def __init__(self, iam: TokenClientConfig):
        self._settings = iam
        self._token: AccessToken | None = None
        self._lock = asyncio.Lock()

    def _token_url(self) -> str:
        """
        Build the full URL for the token endpoint.

        :return: Full token endpoint URL as a string
        """
        return f"{self._settings.base_url.rstrip('/')}{self._settings.token_path}"

    def _is_valid(self) -> bool:
        """
        Check if the cached token exists and is still valid.

        :return: True if token exists and is valid, False otherwise
        """
        return bool(self._token and self._token.is_valid(self._settings.refresh_skew_seconds))

    async def _fetch_token(self) -> AccessToken:
        """
        Fetch a new access token from the IAM service.

        :raises TokenError: If the response does not contain 'access_token'
        :return: AccessToken instance with token and expiration
        """
        payload = {
            "grant_type": "client_credentials",
            "client_id": self._settings.client_id,
            "client_secret": self._settings.client_secret,
        }

        if self._settings.audience:
            payload["aud"] = self._settings.audience

        if self._settings.scope:
            payload["scope"] = self._settings.scope

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(self._token_url(), json=payload)
            if resp.status_code == 401:
                raise TokenError(
                    f"Authentication failed: Invalid client credentials. "
                    f"Client ID: {self._settings.client_id}, "
                    f"Token URL: {self._token_url()}"
                )
            resp.raise_for_status()
            data = resp.json()

        if "access_token" not in data:
            raise TokenError("access_token missing")

        return AccessToken(
            access_token=data["access_token"],
            token_type=data.get("token_type", "Bearer"),
            expires_at=time.time() + float(data.get("expires_in", 60)),
        )

    async def get_token(self, *, force_refresh: bool = False) -> str:
        """
        Get a valid access token, optionally forcing a refresh.

        :param force_refresh: If True, always fetch a new token even if the cached one is valid
        :return: Access token string
        """
        if not force_refresh and self._is_valid():
            return self._token.access_token  # type: ignore

        async with self._lock:
            if not force_refresh and self._is_valid():
                return self._token.access_token  # type: ignore

            self._token = await self._fetch_token()
            return self._token.access_token

    async def get_auth_header(self) -> dict[str, str]:
        """
        Get the Authorization header using the current valid token.

        :return: Dictionary containing the Authorization header
        """
        token = await self.get_token()
        return {"Authorization": f"Bearer {token}"}
