"""
Custom exceptions for integration and authentication errors.
"""


class IntegrationError(Exception):
    """
    Base exception for all integration-related issues.
    """


class TokenError(IntegrationError):
    """
    Raised specifically when there is a problem with authentication tokens.
    """
