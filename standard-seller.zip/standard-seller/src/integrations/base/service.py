"""
Base class for service clients that perform HTTP requests with IAM token authorization.
"""

from src.integrations.base.http import BaseHTTPClient
from src.integrations.base.tokens import OAuthClientCredentialsTokenProvider


class AbstractServiceClient:
    """
    Abstract service client handling authorized HTTP requests.

    :param base_url: The base URL of the service (trailing slash will be removed).
    :param http: An instance of BaseHTTPClient to perform HTTP requests.
    :param token_provider: Token provider for obtaining IAM authorization headers.
    """

    def __init__(
            self,
            base_url: str,
            http: BaseHTTPClient,
            token_provider: OAuthClientCredentialsTokenProvider
    ):
        self._base_url = base_url.rstrip("/")
        self._http = http
        self._token_provider = token_provider

    async def _authorized_request(self, method: str, path: str, **kwargs):
        """
        Perform an HTTP request with IAM token authorization.

        :param method: HTTP method to use (e.g., "GET", "POST").
        :param path: URL path relative to the base URL.
        :param kwargs: Additional arguments forwarded to the HTTP client request.
        :return: The HTTP response object from the request.
        """
        headers = dict(kwargs.pop("headers", {}))

        auth_header = await self._token_provider.get_auth_header()
        if "Authorization" not in auth_header:
            raise RuntimeError("Missing Authorization header from token provider")

        headers["Authorization"] = auth_header["Authorization"]

        url = f"{self._base_url}{path}"
        return await self._http.request(method, url, headers=headers, **kwargs)
