"""
Protocol definitions for application configuration.
"""

from typing import Protocol
from typing import Optional
from dataclasses import dataclass


class TokenClientConfig(Protocol):
    """
    Configuration for a client that fetches OAuth2 tokens from an IAM service.
    """
    base_url: str
    token_path: str
    client_id: str
    client_secret: str
    audience: Optional[str]
    scope: Optional[str]
    refresh_skew_seconds: float


class HttpClientSettings(Protocol):
    """
    Protocol for HTTP client configuration.

    :param timeout: Total timeout for requests in seconds.
    :param connect_timeout: Timeout for connection establishment in seconds.
    :param retries: Number of retries on request failure.
    :param pool_connections: Number of connection pools to maintain.
    :param pool_maxsize: Maximum number of connections per pool.
    """
    timeout: float
    connect_timeout: float
    retries: int
    pool_connections: int
    pool_maxsize: int


@dataclass
class OAuthClientConfig:
    """
    IAM settings for any service integration
    """
    base_url: str
    token_path: str
    client_id: str
    client_secret: str
    audience: Optional[str] = None
    scope: Optional[str] = None
    refresh_skew_seconds: float = 30.0
