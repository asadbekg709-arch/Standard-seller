"""
Module defining the AccessToken dataclass for OAuth2 token handling and validation.
"""

import time

from dataclasses import dataclass


@dataclass(frozen=True)
class AccessToken:
    """
    Represents an OAuth2 access token with expiration handling.

    :param access_token: The token string used for authorization.
    :param token_type: The type of the token (e.g., "Bearer").
    :param expires_at: The Unix timestamp at which the token expires.
    """
    access_token: str
    token_type: str
    expires_at: float

    def is_valid(self, skew: float) -> bool:
        """
        Check whether the token is still valid, considering a clock skew.

        :param skew: Time in seconds to subtract from expiration for early invalidation.
        :return: True if the token is valid, False if expired or within the skew period.
        """
        return time.time() < (self.expires_at - skew)
