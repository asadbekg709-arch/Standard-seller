"""
Asynchronous HTTP client wrapper with retry and connection pool management.
"""

import httpx

from src.integrations.base.errors import IntegrationError
from src.integrations.base.protocols import HttpClientSettings


class BaseHTTPClient:
    """
    Base HTTP client for asynchronous requests with retry logic.

    :param settings: Configuration for HTTP settings.
    """

    def __init__(self, settings: HttpClientSettings):
        self._settings = settings

        self._client = httpx.AsyncClient(
            timeout=self._settings.timeout,
            limits=httpx.Limits(
                max_connections=self._settings.pool_connections,
                max_keepalive_connections=self._settings.pool_maxsize
            )
        )

    async def request(self, method: str, url: str, **kwargs) -> httpx.Response:
        """
        Perform an HTTP request with retry logic.

        :param method: HTTP method to use (e.g., "GET", "POST").
        :param url: URL for the request.
        :param kwargs: Additional arguments passed to httpx.AsyncClient.request.
        :return: The HTTP response object if the request succeeds.
        """
        last_exc = None

        for _ in range(self._settings.retries + 1):
            try:
                resp = await self._client.request(method, url, **kwargs)
                resp.raise_for_status()
                return resp
            except Exception as e:
                last_exc = e

        raise IntegrationError(str(last_exc))
