"""
Client for interacting with the IAM service.
"""

import asyncio

from src.integrations.base.http import BaseHTTPClient
from src.integrations.base.service import AbstractServiceClient
from src.integrations.base.tokens import OAuthClientCredentialsTokenProvider

from src.core.configs import settings

iam_token_provider = OAuthClientCredentialsTokenProvider(settings.integrations.iam)
http_client = BaseHTTPClient(settings.http_client)


class IAMClient(AbstractServiceClient):
    """
    IAM service client for performing authorized API calls.
    """

    def __init__(self):
        """
        Initialize the IAMClient with preconfigured HTTP client and token provider.
        """
        super().__init__(
            base_url=settings.integrations.iam.base_url,
            http=http_client,
            token_provider=iam_token_provider
        )

    async def get_current_user(self):
        """
        Retrieve information about the currently authenticated IAM user.

        :return: A dictionary representing the current user's details.
        """
        resp = await self._authorized_request("GET", "/users/me")
        return resp.json()

    async def get_user_by_id(self, user_id: str):
        """
        Retrieve information about a specific IAM user by their user ID.

        :param user_id: The ID of the user to retrieve.
        :return: A dictionary representing the user's details.
        """
        resp = await self._authorized_request("GET", f"/users/{user_id}")
        return resp.json()


async def main():
    """
    Test function
    """
    client = IAMClient()
    try:
        token = await client._token_provider.get_token()
        print(f"Access token: {token[:50]}...")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
