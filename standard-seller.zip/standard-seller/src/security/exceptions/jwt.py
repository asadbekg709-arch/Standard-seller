"""
Custom JWT-related exceptions.
"""

from typing import Optional


class JWTVerificationError(Exception):
    """
    Base exception for JWT verification errors.
    """

    def __init__(self, message: str, *, details: Optional[str] = None):
        self.details = details
        super().__init__(message)


class JWTExpiredError(JWTVerificationError):
    """
    Raised when the JWT token is expired.
    """


class JWTInvalidSignatureError(JWTVerificationError):
    """
    Raised when the JWT signature validation fails.
    """


class JWTInvalidAudienceError(JWTVerificationError):
    """
    Raised when the audience claim does not match.
    """


class JWTInvalidIssuerError(JWTVerificationError):
    """
    Raised when the issuer claim is invalid.
    """
