"""
JWKS (JSON Web Key Set) utilities for JWT verification.
"""

import time
import httpx
import base64

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from src.core.configs import settings


def base64url_decode(input_str: str) -> bytes:
    """
    Decode a base64url-encoded string into bytes.

    :param input_str: Base64url-encoded string.
    :return: Decoded bytes.
    """
    padding = 4 - (len(input_str) % 4)
    if padding != 4:
        input_str += '=' * padding

    input_str = input_str.replace('-', '+').replace('_', '/')
    return base64.b64decode(input_str)


class JWKSClient:
    """
    JWKS client that fetches public keys from a JWKS endpoint and caches them in memory.
    Supports key retrieval by `kid` and automatic refresh based on TTL.
    """

    def __init__(self):
        """
        Initialize JWKSClient with empty cache and last fetch timestamp.
        """
        self._keys: dict[str, str] = {}  # kid -> PEM key
        self._last_fetch: float = 0
        self._cache_ttl: int = settings.jwt.jwks_cache_ttl

    async def get_signing_key(self, kid: str) -> str:
        """
        Retrieve a public key by its `kid`. Refreshes cache if expired or key not found.

        :param kid: Key ID to look up in JWKS.
        :return: Public key in PEM format.
        :raises ValueError: If the key with the given `kid` is not found.
        """
        now = time.time()
        cache_expired = (now - self._last_fetch) > self._cache_ttl

        if kid not in self._keys or cache_expired:
            await self._fetch_jwks()

        if kid not in self._keys:
            raise ValueError(f"Key with kid '{kid}' not found in JWKS")

        return self._keys[kid]

    async def get_default_signing_key(self) -> str:
        """
        Retrieve the first available signing key (default key).

        :return: Public key in PEM format.
        :raises ValueError: If no keys are available in JWKS.
        """
        now = time.time()
        cache_expired = (now - self._last_fetch) > self._cache_ttl

        if not self._keys or cache_expired:
            await self._fetch_jwks()

        if not self._keys:
            raise ValueError("No keys found in JWKS")

        first_kid = next(iter(self._keys))
        return self._keys[first_kid]

    async def _fetch_jwks(self) -> None:
        """
        Fetch JWKS data from the configured endpoint and populate in-memory cache.

        :raises httpx.HTTPStatusError: If the HTTP request to JWKS URL fails.
        :raises ValueError: If key data is malformed.
        """
        jwks_url = settings.jwt.jwks_url

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(jwks_url)
            response.raise_for_status()
            jwks_data = response.json()

        self._keys = {}
        for key_data in jwks_data.get("keys", []):
            kid = key_data.get("kid")
            if not kid:
                continue

            if key_data.get("kty") == "RSA":
                n = int.from_bytes(base64url_decode(key_data["n"]), "big")
                e = int.from_bytes(base64url_decode(key_data["e"]), "big")

                public_key = rsa.RSAPublicNumbers(e, n).public_key(default_backend())
                pem = public_key.public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                ).decode("utf-8")

                self._keys[kid] = pem

        self._last_fetch = time.time()

    def clear_cache(self) -> None:
        """
        Clear the JWKS cache and reset the last fetch timestamp.
        """
        self._keys = {}
        self._last_fetch = 0


_jwks_client: JWKSClient | None = None


def get_jwks_client() -> JWKSClient:
    """
    Get a singleton instance of JWKSClient.

    :return: JWKSClient instance.
    """
    global _jwks_client
    if _jwks_client is None:
        _jwks_client = JWKSClient()
    return _jwks_client
