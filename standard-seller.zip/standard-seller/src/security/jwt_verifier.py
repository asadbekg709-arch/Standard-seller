"""
JWT verification utilities.
"""

import jwt

from typing import Any

from fastapi import status
from fastapi import HTTPException

from jwt import InvalidTokenError
from jwt import InvalidAudienceError
from jwt import ExpiredSignatureError
from jwt import InvalidSignatureError

from src.core.configs import settings
from src.security.jwks import get_jwks_client


class JWTVerificationError(Exception):
    """
    Base exception for JWT verification errors.
    """


class JWTExpiredError(JWTVerificationError):
    """
    Raised when a JWT token has expired.
    """


class JWTInvalidSignatureError(JWTVerificationError):
    """
    Raised when JWT signature verification fails.
    """


class JWTInvalidAudienceError(JWTVerificationError):
    """
    Raised when the JWT audience is invalid.
    """


class JWTInvalidIssuerError(JWTVerificationError):
    """
    Raised when the JWT issuer or claims are invalid.
    """


async def verify_jwt(token: str) -> dict[str, Any]:
    """
    Verify a JWT token using JWKS (JSON Web Key Set).

    :param token: JWT string to verify.
    :return: Decoded JWT claims as a dictionary.
    :raises JWTExpiredError: If the token has expired.
    :raises JWTInvalidAudienceError: If the token audience is invalid.
    :raises JWTInvalidSignatureError: If the token signature is invalid.
    :raises JWTInvalidIssuerError: If the token issuer or claims are invalid.
    :raises JWTVerificationError: For other unexpected JWT verification errors.
    """
    try:
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")
        jwks_client = get_jwks_client()

        signing_key = (
            await jwks_client.get_signing_key(kid)
            if kid
            else await jwks_client.get_default_signing_key()
        )

        claims = jwt.decode(
            token,
            signing_key,
            algorithms=[settings.jwt.algorithm],
            audience=settings.jwt.audience or None,
            issuer=settings.jwt.issuer,
        )

        return claims

    except ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="JWT token has expired",
        )
    except InvalidAudienceError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid audience: {e}",
        )
    except InvalidSignatureError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"JWT signature verification failed: {e}",
        )
    except InvalidTokenError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid issuer or token claims: {e}",
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unexpected JWT verification error: {e}",
        )


def extract_roles_from_claims(claims: dict[str, Any]) -> list[str]:
    """
    Extract normalized role strings from JWT claims.

    :param claims: Decoded JWT claims.
    :return: List of role strings in lowercase, with leading/trailing spaces stripped.
             Returns an empty list if no roles are found or claim is invalid.
    """
    roles_claim_name = settings.jwt.roles_claim
    roles = claims.get(roles_claim_name, [])

    if isinstance(roles, str):
        roles = [roles]
    elif not isinstance(roles, list):
        roles = []

    return [
        role.strip().lower()
        for role in roles
        if isinstance(role, str) and role.strip()
    ]
