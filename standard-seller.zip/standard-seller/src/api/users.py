"""
User API routers
"""

from uuid import UUID

from typing import Any

from fastapi import status
from fastapi import APIRouter

from src.services.users import UsersService

from src.api.dependencies import AuthDep
from src.api.dependencies import SortingDep
from src.api.dependencies import PaginationDep
from src.api.dependencies import DbTransactionDep

from src.schemas.users import UserReadSchema
from src.schemas.users import UserCreateSchema
from src.schemas.users import UserUpdateSchema
from src.schemas.pagination import PaginatedResponseSchema

from src.exceptions.service.users import UserNotFound
from src.exceptions.service.users import UserAlreadyExists
from src.exceptions.api.users import UserNotFoundHTTPException
from src.exceptions.api.users import UserAlreadyExistsHTTPException


router = APIRouter(
    prefix="/users",
    tags=["Users"],
)


@router.get(
    "",
    response_model=PaginatedResponseSchema,
    status_code=status.HTTP_200_OK,
    summary="Get Users List",
    description="Retrieve a paginated list of users with optional email search.",
)
async def list_users(
    auth: AuthDep,
    db: DbTransactionDep,
    pagination: PaginationDep,
    sorting: SortingDep,
) -> PaginatedResponseSchema:
    """
    Retrieve a paginated list of users.

    :param db: Database session dependency
    :param pagination: Pagination parameters (limit, offset, current_page)
    :return: PaginatedResponseSchema containing list of users and pagination info
    """
    return await UsersService(db).get_list(
        limit=pagination.limit,
        offset=pagination.offset,
        current_page=pagination.current_page,
        sort_field=sorting.sort_field,
        sort_order=sorting.sort_order,
    )


@router.get(
    "/{user_id}",
    response_model=UserReadSchema,
    status_code=status.HTTP_200_OK,
)
async def get_user(
    auth: AuthDep,
    user_id: UUID,
    db: DbTransactionDep,
) -> UserReadSchema:
    """
    Retrieve a single user by ID.

    :param user_id: UUID of the user to retrieve
    :param db: Database session dependency
    :return: UserReadSchema containing user data
    :raises UserNotFoundHTTPException: If the user does not exist
    """
    try:
        return await UsersService(db).get_one_by_id(user_id)
    except UserNotFound as ex:
        raise UserNotFoundHTTPException from ex


@router.post(
    "",
    response_model=UserReadSchema,
    status_code=status.HTTP_201_CREATED,
)
async def create_user(
    auth: AuthDep,
    db: DbTransactionDep,
    data: UserCreateSchema
) -> UserReadSchema:
    """
    Create a new user.

    :param db: Database session dependency
    :param data: UserCreateSchema containing user creation data
    :return: UserReadSchema of the newly created user
    :raises UserAlreadyExistsHTTPException: If a user with the same unique fields already exists
    """
    try:
        return await UsersService(db).create(data)
    except UserAlreadyExists as ex:
        raise UserAlreadyExistsHTTPException from ex


@router.patch(
    "/{user_id}",
    response_model=UserReadSchema,
    status_code=status.HTTP_200_OK,
)
async def update_user(
    auth: AuthDep,
    user_id: UUID,
    db: DbTransactionDep,
    data: UserUpdateSchema
) -> UserReadSchema:
    """
    Update an existing user by ID.

    :param user_id: UUID of the user to update
    :param db: Database session dependency
    :param data: UserUpdateSchema containing updated user data
    :return: UserReadSchema of the updated user
    :raises UserNotFoundHTTPException: If the user does not exist
    """
    try:
        return await UsersService(db).update(user_id, data)
    except UserNotFound as ex:
        raise UserNotFoundHTTPException from ex


@router.delete(
    "/{user_id}",
    status_code=status.HTTP_200_OK,
)
async def delete_user(
    auth: AuthDep,
    user_id: UUID,
    db: DbTransactionDep
) -> dict[str, Any]:
    """
    Delete a user by ID.

    :param user_id: UUID of the user to delete
    :param db: Database session dependency
    :return: Dictionary with status and deleted user ID
    :raises UserNotFoundHTTPException: If the user does not exist
    """
    try:
        deleted_id = await UsersService(db).delete(user_id)
        return {"status": "success", "id": deleted_id}
    except UserNotFound as ex:
        raise UserNotFoundHTTPException from ex
