"""
Scope-based authorization for FastAPI routes.
"""

from typing import Annotated

from fastapi import status
from fastapi import Depends
from fastapi import HTTPException

from src.schemas.auth import AuthContext

from src.api.dependencies.auth import extract_auth_context


def require_scope(*required_scopes: str):
    """
    Dependency that requires the user to have at least one of the specified scopes.
    """
    async def check_scope(
        auth: Annotated[AuthContext, Depends(extract_auth_context)],
    ) -> AuthContext:
        user_scopes = set(auth.scopes)

        if "*" in user_scopes:
            return auth

        required_set = set(required_scopes)

        if not user_scopes & required_set:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "FORBIDDEN",
                    "message": "Insufficient permissions to access this resource",
                    "required_scopes": list(required_scopes),
                },
            )
        return auth

    return check_scope


def require_all_scopes(*required_scopes: str):
    """
    Dependency that requires the user to have ALL of the specified scopes.
    """
    async def check_all_scopes(
        auth: Annotated[AuthContext, Depends(extract_auth_context)],
    ) -> AuthContext:
        user_scopes = set(auth.scopes)

        if "*" in user_scopes:
            return auth

        required_set = set(required_scopes)

        if not required_set.issubset(user_scopes):
            missing = required_set - user_scopes
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "FORBIDDEN",
                    "message": "Insufficient permissions to access this resource",
                    "required_scopes": list(required_scopes),
                    "missing_scopes": list(missing),
                },
            )
        return auth

    return check_all_scopes


def require_staff(
    auth: Annotated[AuthContext, Depends(extract_auth_context)],
) -> AuthContext:
    """
    Dependency that requires the user to be a staff member.
    """
    if not auth.is_staff:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "FORBIDDEN",
                "message": "Staff access required",
            },
        )

    return auth


def require_permission(*required_perms: str):
    """
    Dependency that requires the user to have at least one of the specified permissions.
    """
    async def check_permission(
        auth: Annotated[AuthContext, Depends(extract_auth_context)],
    ) -> AuthContext:
        user_perms = set(auth.permissions)

        if "*" in user_perms:
            return auth

        required_set = set(required_perms)

        if not user_perms & required_set:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "FORBIDDEN",
                    "message": "Insufficient permissions to access this resource",
                    "details": {
                        "required_permissions": list(required_perms),
                        "user_permissions": auth.permissions,
                    },
                },
            )

        return auth

    return check_permission


def require_all_permissions(*required_perms: str):
    """
    Dependency that requires the user to have ALL of the specified permissions.
    """
    async def check_all_permissions(
        auth: Annotated[AuthContext, Depends(extract_auth_context)],
    ) -> AuthContext:
        user_perms = set(auth.permissions)

        if "*" in user_perms:
            return auth

        required_set = set(required_perms)

        if not required_set.issubset(user_perms):
            missing = required_set - user_perms
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "FORBIDDEN",
                    "message": "Insufficient permissions to access this resource",
                    "details": {
                        "required_permissions": list(required_perms),
                        "missing_permissions": list(missing),
                        "user_permissions": auth.permissions,
                    },
                },
            )

        return auth

    return check_all_permissions


def has_permission(auth: AuthContext, permission: str) -> bool:
    """
    Check if user has a specific permission.
    """
    if "*" in auth.permissions:
        return True

    return permission in auth.permissions


def has_any_permission(auth: AuthContext, *permissions: str) -> bool:
    """
    Check if user has any of the specified permissions.
    """
    if "*" in auth.permissions:
        return True

    return any(perm in auth.permissions for perm in permissions)


def has_all_permissions(auth: AuthContext, *permissions: str) -> bool:
    """
    Check if user has all of the specified permissions.
    """
    if "*" in auth.permissions:
        return True

    return all(perm in auth.permissions for perm in permissions)


RequireStaffDep = Annotated[
    AuthContext,
    Depends(require_staff)
]
