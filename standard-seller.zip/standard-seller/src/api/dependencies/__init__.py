"""
Initialization of API dependencies.
"""

from src.api.dependencies.auth import AuthDep
from src.api.dependencies.db import DbReadonlyDep
from src.api.dependencies.sorting import SortingDep
from src.api.dependencies.db import DbTransactionDep
from src.api.dependencies.pagination import PaginationDep
from src.api.dependencies.permission import RequireStaffDep

from src.api.dependencies.permission import require_staff
from src.api.dependencies.permission import has_permission
from src.api.dependencies.permission import require_permission
from src.api.dependencies.permission import has_any_permission
from src.api.dependencies.permission import has_all_permissions
from src.api.dependencies.permission import require_all_permissions


__all__ = (
    "AuthDep",
    "SortingDep",
    "PaginationDep",
    "DbReadonlyDep",
    "DbTransactionDep",
    "RequireStaffDep",
    "require_permission",
    "require_all_permissions",
    "require_staff",
    "has_permission",
    "has_any_permission",
    "has_all_permissions",
)
