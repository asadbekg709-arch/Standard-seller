"""
Authorization dependency for FastAPI routes.
"""

from uuid import UUID

from typing import Annotated

from fastapi import status
from fastapi import Depends
from fastapi import Request
from fastapi import HTTPException
from fastapi.security import HTTPBearer
from fastapi.security import HTTPAuthorizationCredentials

from src.enums.auth import ActorType
from src.schemas.auth import AuthContext

from src.security.jwt_verifier import verify_jwt
from src.security.jwt_verifier import extract_roles_from_claims


bearer_scheme = HTTPBearer(auto_error=False, description="JWT Bearer token")


async def extract_auth_context(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> AuthContext:
    """
    Extract minimal authentication context (AuthContext) from a JWT for protected endpoints.

    This dependency parses the JWT from either the Authorization header or
    the HTTPBearer credentials, verifies it, and extracts the user ID, email,
    roles, and staff status.

    :param request: FastAPI Request object, used to read headers if credentials are missing.
    :param credentials: Optional HTTPAuthorizationCredentials provided by HTTPBearer.
    :return: AuthContext containing user_id, email, roles, and is_staff flag.
    :raises HTTPException:
        - 401 Unauthorized if the token is missing or invalid
        - 401 Unauthorized if the 'sub' claim is missing or not a valid UUID
    """
    token: str | None = None

    if credentials:
        token = credentials.credentials
    else:
        header = request.headers.get("Authorization", "")
        if header.startswith("Bearer "):
            token = header[7:].strip()

    if not token:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Unauthorized")

    claims = await verify_jwt(token)

    sub = claims.get("sub")
    if not sub:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Unauthorized")

    try:
        actor_id = UUID(sub)
        actor_type = ActorType.user
    except ValueError:
        if sub.startswith("client:"):
            actor_id = sub
            actor_type = ActorType.service
        else:
            raise HTTPException(
                status.HTTP_401_UNAUTHORIZED,
                "Invalid sub format",
            )

    return AuthContext(
        actor_type=actor_type,
        actor_id=actor_id,
        email=claims.get("email"),
        roles=extract_roles_from_claims(claims),
        is_staff=False,
    )


AuthDep = Annotated[
    AuthContext,
    Depends(extract_auth_context)
]
