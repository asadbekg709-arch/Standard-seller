"""
Sorting dependencies for FastAPI routes.
"""

from typing import Annotated

from fastapi import Query
from fastapi import Depends

from src.enums.sorting import SortOrder


class SortingParams:
    """
    Structured sorting parameters for API endpoints.
    """

    def __init__(
        self,
        sort_field: str | None = Query(
            None, description="Field to sort by (depends on resource)"
        ),
        sort_order: SortOrder = Query(
            SortOrder.DESC, description="Sorting direction: asc or desc"
        ),
    ):
        self.sort_field = sort_field
        self.sort_order = sort_order


SortingDep = Annotated[
    SortingParams,
    Depends()
]
