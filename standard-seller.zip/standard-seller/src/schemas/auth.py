from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field


class AuthContext(BaseModel):
    """Authentication context extracted from gateway headers."""

    user_id: UUID = Field(..., description="User UUID from X-User-Id header")
    email: str = Field(..., description="User email from X-User-Email header")
    roles: list[str] = Field(
        default_factory=list,
        description="Normalized lowercase roles from X-User-Roles header",
    )
    is_staff: bool = Field(False, description="Staff flag from X-Is-Staff header")

    class Config:
        frozen = True  # Immutable for safety


class AdminMeResponse(BaseModel):
    """Response for GET /mobile/auth/me endpoint showing admin access."""

    user_id: str = Field(..., description="User UUID")
    roles: list[str] = Field(..., description="User's roles (normalized)")
    allowed_modules: list[str] = Field(
        ..., description="Modules accessible to this user (A, B, C, D)"
    )


# Login Schemas
class LoginByEmailRequest(BaseModel):
    """Request schema for email-based login."""

    email: EmailStr = Field(..., description="User email address")
    password: str = Field(..., min_length=8, description="User password")


class LoginByPhoneRequest(BaseModel):
    """Request schema for phone-based login."""

    phone: str = Field(..., min_length=10, description="User phone number")
    password: str = Field(..., min_length=8, description="User password")


class TokenResponse(BaseModel):
    """Response schema for successful authentication."""

    access_token: str = Field(..., description="JWT access token")
    refresh_token: str = Field(..., description="Refresh token for obtaining new access tokens")
    token_type: str = Field(default="bearer", description="Token type")
    expires_in: int = Field(..., description="Access token expiration time in seconds")
    user_id: str = Field(..., description="User UUID")
    email: str = Field(..., description="User email")
    roles: list[str] = Field(default_factory=list, description="User roles")


# Logout Schemas
class LogoutRequest(BaseModel):
    """Request schema for logout."""

    refresh_token: str = Field(..., description="Refresh token to revoke")


class LogoutResponse(BaseModel):
    """Response schema for successful logout."""

    message: str = Field(default="Successfully logged out", description="Logout message")


# Refresh Token Schemas
class RefreshTokenRequest(BaseModel):
    """Request schema for refreshing access token."""

    refresh_token: str = Field(..., description="Valid refresh token")


# Permission Schemas
class PermissionCheck(BaseModel):
    """Individual permission check."""

    resource: str = Field(..., description="Resource name (e.g., 'cameras', 'parking')")
    action: str = Field(..., description="Action name (e.g., 'view', 'edit', 'delete')")


class CheckPermissionsRequest(BaseModel):
    """Request schema for checking multiple permissions."""

    permissions: list[PermissionCheck] = Field(
        ..., description="List of permissions to check"
    )


class PermissionResult(BaseModel):
    """Result of a single permission check."""

    resource: str = Field(..., description="Resource name")
    action: str = Field(..., description="Action name")
    granted: bool = Field(..., description="Whether permission is granted")


class CheckPermissionsResponse(BaseModel):
    """Response schema for permission checks."""

    user_id: str = Field(..., description="User UUID")
    permissions: list[PermissionResult] = Field(
        ..., description="List of permission check results"
    )
    can_view_cameras: bool = Field(..., description="Camera viewing permission")
    can_use_parking: bool = Field(..., description="Parking usage permission")


class UserPermissions(BaseModel):
    """User's feature permissions."""

    user_id: UUID = Field(..., description="User UUID")
    can_view_cameras: bool = Field(default=True, description="Camera viewing permission")
    can_use_parking: bool = Field(default=True, description="Parking usage permission")
    updated_at: datetime = Field(..., description="Last update timestamp")
