"""
Base Repository methods.
"""

import uuid

from typing import Any
from typing import TypeVar
from typing import Generic
from typing import Iterable

from pydantic import BaseModel

from sqlalchemy import asc
from sqlalchemy import desc
from sqlalchemy import or_
from sqlalchemy import func
from sqlalchemy import insert
from sqlalchemy import select
from sqlalchemy import update
from sqlalchemy.exc import NoResultFound
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import with_loader_criteria
from sqlalchemy.sql import exists as sql_exists
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.postgres import Base
from src.enums.sorting import SortOrder
from src.mappers.base import BaseDataMapper
from src.exceptions.repository.base import ObjectNotFoundRepoException
from src.exceptions.repository.base import CannotAddObjectRepoException


T = TypeVar("T")


class BaseRepository(Generic[T]):
    """
    Base repository providing generic CRUD operations for SQLAlchemy models.
    """

    model: type[Base] = None
    mapper: type[BaseDataMapper] = None

    def __init__(self, session: AsyncSession):
        """
        Initialize repository with an async SQLAlchemy session.

        :param session: AsyncSession instance for DB operations.
        """

        self.session = session

    def _active_filter(self, query):
        """
        Apply `deleted_at IS NULL` filter for the primary entity if available.

        :param query: SQLAlchemy query object.
        :return: Query with active filter applied.
        """

        if hasattr(self.model, "deleted_at"):
            query = query.where(self.model.deleted_at.is_(None))
        return query

    def apply_sorting(
        self,
        query,
        sort_field: str | None = None,
        sort_order: SortOrder = SortOrder.DESC,
        allowed_fields: dict[str, Any] | None = None,
    ):
        """
        Apply sorting to a SQLAlchemy query.

        :param query: SQLAlchemy query object.
        :param sort_field: Field name to sort by (must be in allowed_fields).
        :param sort_order: Sorting direction (asc or desc).
        :param allowed_fields: Dict mapping field names to model columns or SQL expressions.
        :return: Query with sorting applied.
        """
        if not allowed_fields:
            return query.order_by(desc(self.model.id))

        if sort_field and sort_field in allowed_fields:
            column = allowed_fields[sort_field]
        else:
            column = allowed_fields.get(
                "created_at", self.model.id
            )

        order = asc(column) if sort_order == SortOrder.ASC else desc(column)
        return query.order_by(order, self.model.id)

    def _with_active_children(self, query):
        """
        Apply `deleted_at IS NULL` filter to all child relationships
        that support soft deletion.

        :param query: SQLAlchemy query object.
        :return: Query with child filters applied.
        """

        if hasattr(self.model, "__mapper__"):
            for rel in self.model.__mapper__.relationships:
                child_model = rel.mapper.class_
                if hasattr(child_model, "deleted_at"):
                    query = query.options(
                        with_loader_criteria(
                            child_model, child_model.deleted_at.is_(None)
                        )
                    )
        return query

    async def get_one(
        self, query_options: Iterable = None, with_rels: bool = False, **filter_by
    ) -> T:
        """
        Retrieve a single object matching the filter.

        :param query_options: Optional SQLAlchemy loader options.
        :param with_rels: Whether to include related entities with active filter applied.
        :param filter_by: Field-based filters (e.g., id=uuid).
        :return: Domain entity mapped object.
        :raises ObjectNotFoundRepoException: If no matching object is found.
        """

        query = select(self.model).filter_by(**filter_by)
        query = self._active_filter(query)

        if with_rels:
            query = self._with_active_children(query)

        if query_options:
            query = query.options(*query_options)

        result = await self.session.execute(query)
        try:
            model = result.scalar_one()
        except NoResultFound as ex:
            raise ObjectNotFoundRepoException from ex

        return self.mapper.map_to_domain_entity(model, with_rels=with_rels)

    async def get_all(
        self,
        limit: int = 20,
        offset: int = 0,
        with_rels: bool = False,
        search: str | None = None,
        sort_field: str | None = None,
        sort_order: SortOrder = SortOrder.DESC,
        allowed_sort_fields: dict[str, Any] | None = None,
        **filter_by,
    ) -> list[T]:
        """
        Retrieve a paginated list of objects.

        :param limit: Maximum number of records to return.
        :param offset: Number of records to skip before returning results.
        :param with_rels: Whether to include related entities with active filter applied.
        :param search: Optional search term applied to JSONB fields (uz/ru/en).
        :param sort_field: Optional field name to sort by.
        :param sort_order: Sorting direction (asc or desc).
        :param allowed_sort_fields: Dict mapping allowed sort names to SQLAlchemy columns/expressions.
        :param filter_by: Field-based filters for narrowing results.
        :return: List of domain entities mapped from model instances.
        """

        if limit < 0 or offset < 0:
            raise ValueError("Limit and offset must be non-negative.")

        query = select(self.model)
        query = self._active_filter(query)

        if filter_by:
            query = query.filter_by(**filter_by)

        if search and hasattr(self.model, "name"):
            query = query.where(
                or_(
                    self.model.name["uz"].astext.ilike(f"%{search}%"),
                    self.model.name["ru"].astext.ilike(f"%{search}%"),
                    self.model.name["en"].astext.ilike(f"%{search}%"),
                )
            )

        if with_rels:
            query = self._with_active_children(query)

        query = self.apply_sorting(
            query=query,
            sort_field=sort_field,
            sort_order=sort_order,
            allowed_fields=allowed_sort_fields,
        ).limit(limit).offset(offset)

        result = await self.session.execute(query)
        return [
            self.mapper.map_to_domain_entity(m, with_rels=with_rels)
            for m in result.scalars().all()
        ]

    async def get_one_or_none(self, **filter_by) -> T | None:
        """
        Retrieve a single object matching the filter, or return None.

        :param filter_by: Field-based filters.
        :return: Domain entity or None if no match.
        """

        query = select(self.model).filter_by(**filter_by)
        query = self._active_filter(query)
        result = await self.session.execute(query)
        model = result.scalar_one_or_none()
        if model is None:
            return None
        return self.mapper.map_to_domain_entity(model)

    async def add(self, data: BaseModel) -> T:
        """
        Add a single object to the database.

        :param data: Pydantic model containing the data.
        :return: Domain entity of the newly added object.
        :raises CannotAddObjectRepoException: If integrity constraint fails.
        """

        stmt = insert(self.model).values(**data.model_dump()).returning(self.model)
        try:
            result = await self.session.execute(stmt)
            model = result.scalar_one()
        except IntegrityError as ex:
            # IntegrityError marks the transaction as failed; clear it early so
            # callers that catch this exception don't hit PendingRollbackError.
            await self.session.rollback()
            detail = str(getattr(ex, "orig", ex))
            raise CannotAddObjectRepoException(detail) from ex
        return self.mapper.map_to_domain_entity(model)

    async def add_bulk(self, data: list[BaseModel]) -> None:
        """
        Add multiple objects to the database at once.

        :param data: List of Pydantic models.
        :raises CannotAddObjectRepoException: If integrity constraint fails.
        """

        stmt = insert(self.model).values([item.model_dump() for item in data])
        try:
            await self.session.execute(stmt)
        except IntegrityError as ex:
            await self.session.rollback()
            detail = str(getattr(ex, "orig", ex))
            raise CannotAddObjectRepoException(detail) from ex

    async def update_one(
        self, data: BaseModel, partially: bool = False, **filter_by
    ) -> T:
        """
        Update a single object.

        :param data: Pydantic model containing updated fields.
        :param partially: If True, only update the fields set in the model.
        :param filter_by: Field-based filters to locate the object.
        :return: Updated domain entity.
        :raises ObjectNotFoundRepoException: If object does not exist.
        """

        stmt = (
            update(self.model)
            .values(**data.model_dump(exclude_unset=partially))
            .filter_by(**filter_by)
            .returning(self.model)
        )
        result = await self.session.execute(stmt)
        try:
            model = result.scalar_one()
        except NoResultFound as ex:
            raise ObjectNotFoundRepoException from ex
        return self.mapper.map_to_domain_entity(model)

    async def delete_one(self, **filter_by) -> T:
        """
        Soft-delete a single object by setting `deleted_at` timestamp.

        :param filter_by: Field-based filters to locate the object.
        :return: Deleted domain entity.
        :raises ObjectNotFoundRepoException: If object does not exist.
        """

        stmt = (
            update(self.model)
            .filter_by(**filter_by)
            .where(self.model.deleted_at.is_(None))
            .values(deleted_at=func.now())
            .returning(self.model)
        )
        result = await self.session.execute(stmt)
        model = result.scalar_one_or_none()
        if not model:
            raise ObjectNotFoundRepoException
        return self.mapper.map_to_domain_entity(model)

    async def delete_bulk(self, list_ids: list[uuid.UUID]) -> int:
        """
        Soft-delete multiple objects by setting `deleted_at`.

        :param list_ids: List of UUIDs to delete.
        :return: Number of deleted rows.
        """

        stmt = (
            update(self.model)
            .where(self.model.id.in_(list_ids))
            .where(self.model.deleted_at.is_(None))
            .values(deleted_at=func.now())
        )
        result = await self.session.execute(stmt)
        return result.rowcount or 0

    async def restore_one(self, **filter_by) -> T:
        """
        Restore a soft-deleted object by setting `deleted_at` to NULL.

        :param filter_by: Field-based filters to locate the object.
        :return: Restored domain entity.
        :raises ObjectNotFoundRepoException: If object does not exist or is not deleted.
        """

        stmt = (
            update(self.model)
            .filter_by(**filter_by)
            .where(self.model.deleted_at.is_not(None))
            .values(deleted_at=None)
            .returning(self.model)
        )
        result = await self.session.execute(stmt)
        model = result.scalar_one_or_none()
        if not model:
            raise ObjectNotFoundRepoException
        return self.mapper.map_to_domain_entity(model)

    async def restore_bulk(self, list_ids: list[uuid.UUID]) -> int:
        """
        Restore multiple soft-deleted objects by setting `deleted_at=NULL`.

        :param filter_by: Field-based filters.
        :return: Number of restored rows.
        """

        stmt = (
            update(self.model)
            .where(self.model.id.in_(list_ids))
            .where(self.model.deleted_at.is_not(None))
            .values(deleted_at=None)
        )
        result = await self.session.execute(stmt)
        return result.rowcount or 0

    async def count(self, filters: dict | None = None) -> int:
        """
        Count records in the table with optional filters.

        :param filters: Optional dictionary of field-value filters.
        :return: Number of matching records.
        """

        stmt = select(func.count()).select_from(self.model)
        stmt = self._active_filter(stmt)

        if filters:
            for field, value in filters.items():
                stmt = stmt.where(getattr(self.model, field) == value)

        result = await self.session.execute(stmt)
        return result.scalar_one()

    async def get_many_by_ids(self, ids: Iterable[uuid.UUID]) -> list[T]:
        """
        Retrieve multiple objects by their IDs.

        :param ids: Iterable of UUIDs.
        :return: List of domain entities.
        """

        if not ids:
            return []

        stmt = select(self.model).where(self.model.id.in_(ids))
        stmt = self._active_filter(stmt)

        result = await self.session.execute(stmt)
        models = result.scalars().all()

        return [
            self.mapper.map_to_domain_entity(model)
            for model in models
        ]

    async def exists(self, **filter_by) -> bool:
        """
        Check if a record exists matching given filters,
        respecting soft-deletion if applicable.

        :param filter_by: Field-based filters (e.g. id=UUID)
        :return: True if exists, False otherwise
        """

        if not filter_by:
            raise ValueError("exists() requires at least one filter")

        conditions = [
            getattr(self.model, field) == value
            for field, value in filter_by.items()
        ]

        if hasattr(self.model, "deleted_at"):
            conditions.append(self.model.deleted_at.is_(None))

        stmt = select(sql_exists().where(*conditions))

        result = await self.session.execute(stmt)
        return bool(result.scalar())
