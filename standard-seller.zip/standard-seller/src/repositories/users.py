"""
Repository for User persistence and retrieval.
"""

from src.models.users import Users
from src.enums.sorting import SortOrder
from src.mappers.users import UsersMapper
from src.repositories.base import BaseRepository

from src.exceptions.repository.users import user_repo_exceptions


class UsersRepository(BaseRepository[Users]):
    """
    Repository for managing User persistence and retrieval.
    """

    model = Users
    mapper = UsersMapper

    @user_repo_exceptions
    async def get_one(self, **kwargs):
        """
        Retrieve a single user by given filters.

        :param kwargs: Filter parameters (e.g., id=..., email=...)
        :return: Mapped user object
        """
        return await super().get_one(**kwargs)

    @user_repo_exceptions
    async def get_one_or_none(self, **kwargs):
        """
        Retrieve a single user or None by given filters.

        :param kwargs: Filter parameters
        :return: Mapped user object or None
        """
        return await super().get_one_or_none(**kwargs)

    @user_repo_exceptions
    async def get_all(
        self,
        limit: int = 20,
        offset: int = 0,
        with_rels: bool = False,
        search: str | None = None,
        sort_field: str | None = None,
        sort_order: SortOrder = SortOrder.DESC,
        **kwargs,
    ):
        """
        Retrieve users with pagination and optional sorting.

        Allowed sort fields:
            - id
            - email
            - created_at
            - updated_at
        """

        allowed_sort_fields = {
            "id": self.model.id,
            "email": self.model.email,
            "created_at": self.model.created_at,
            "updated_at": self.model.updated_at,
        }
        return await super().get_all(
            limit=limit,
            offset=offset,
            with_rels=with_rels,
            search=search,
            sort_field=sort_field,
            sort_order=sort_order,
            allowed_sort_fields=allowed_sort_fields,
            **kwargs,
        )

    @user_repo_exceptions
    async def add(self, data):
        """
        Add a new user to the database.

        :param data: User data object to insert
        :return: Mapped user object after insertion
        """
        return await super().add(data)

    @user_repo_exceptions
    async def update_one(self, data, partially: bool = False, **kwargs):
        """
        Update an existing user.

        :param data: User data object with updated fields
        :param partially: If True, perform a partial update
        :param kwargs: Filter parameters to locate the user to update
        :return: Updated user object
        """
        return await super().update_one(data, partially=partially, **kwargs)

    @user_repo_exceptions
    async def delete_one(self, **kwargs):
        """
        Soft delete a user.

        :param kwargs: Filter parameters to locate the user to delete
        :return: Deleted user object
        """
        return await super().delete_one(**kwargs)
