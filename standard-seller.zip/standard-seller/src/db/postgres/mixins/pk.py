"""
Primary key mixins for database models.
"""

import uuid

from sqlalchemy import UUID
from sqlalchemy import text
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class UUIDPkMixin:
    """
    Adds a UUID primary key column to a SQLAlchemy model.

    Attributes:
        id (uuid.UUID): Primary key for the model.
            Automatically generated using `gen_random_uuid()` in the database.
    """

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("gen_random_uuid()"),
    )
