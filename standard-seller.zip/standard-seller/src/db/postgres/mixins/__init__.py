"""
Initialization of database mixins.
"""

from src.db.postgres.mixins.pk import UUIDPkMixin
from src.db.postgres.mixins.timestamp import TimestampMixin
from src.db.postgres.mixins.softdeletion import SoftDeletionMixin


__all__ = (
    "UUIDPkMixin",
    "TimestampMixin",
    "SoftDeletionMixin",
)
