"""
Logging utilities with colored output for better readability.
"""

import sys
import logging

COLORS = {
    "DEBUG": "\033[37m",     # White
    "INFO": "\033[36m",      # Cyan
    "WARNING": "\033[33m",   # Yellow
    "ERROR": "\033[31m",     # Red
    "CRITICAL": "\033[41m",  # Red background
    "RESET": "\033[0m",      # Reset
}


class ColorFormatter(logging.Formatter):
    """
    Custom logging formatter with colors.
    """
    def format(self, record):
        log_color = COLORS.get(record.levelname, COLORS["RESET"])
        record.levelname = f"{log_color}{record.levelname}{COLORS['RESET']}"
        record.msg = f"{log_color}{record.msg}{COLORS['RESET']}"
        return super().format(record)


def get_logger(name: str, level=logging.INFO) -> logging.Logger:
    """
    Return a configured logger with colored output.
    """
    logger = logging.getLogger(name)
    if not logger.hasHandlers():
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)
        formatter = ColorFormatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s") # noqa
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(level)
    return logger


logger = get_logger(__name__)


def log_message(title: str, info: str, level=logging.INFO):
    """
    Logs a message with optional formatting.

    :param title: Short header for the log
    :param info: Detailed info to log
    :param level: Logging level (INFO, DEBUG, WARNING, ERROR, CRITICAL)
    """
    log_func = {
        logging.DEBUG: logger.debug,
        logging.INFO: logger.info,
        logging.WARNING: logger.warning,
        logging.ERROR: logger.error,
        logging.CRITICAL: logger.critical,
    }.get(level, logger.info)

    log_func("="*80)
    log_func(title)
    log_func(info)
    log_func("="*80)
