"""
Database configurations
"""

from pydantic import Field
from pydantic import computed_field
from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict


class PostgresDatabaseSettings(BaseSettings):
    """
    PostgreSQL connection configuration.
    Reads from POSTGRES_* environment variables.
    """
    model_config = SettingsConfigDict(env_prefix="POSTGRES_", frozen=True)

    db: str = Field(default="namuna_db")
    user: str = Field(default="postgres")
    password: str = Field(default="password")
    host: str = Field(default="namuna-db")
    port: int = Field(default=5432)

    @computed_field
    @property
    def url(self) -> str:
        return f"postgresql+asyncpg://{self.user}:{self.password}@{self.host}:{self.port}/{self.db}" # noqa

    def build_url(self) -> str:
        """
        Backward compatibility for Alembic.
        """
        return self.url
