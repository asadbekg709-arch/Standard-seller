"""
Pagination configuraton
"""

from pydantic import Field
from pydantic import field_validator
from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict


class PaginationSettings(BaseSettings):
    """
    Pagination configuration.
    """
    model_config = SettingsConfigDict(frozen=True)

    max_entities_per_page: int = Field(
        default=100,
        ge=1,
        le=1000,
        description="Maximum number of entities per page"
    )

    @field_validator("max_entities_per_page")
    @classmethod
    def validate_page_size(cls, v: int) -> int:
        if not 1 <= v <= 1000:
            raise ValueError("max_entities_per_page must be between 1 and 1000")
        return v
