"""
HTTP client configurations
"""

from pydantic import Field
from pydantic import field_validator

from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict


class HTTPClientSettings(BaseSettings):
    """
    HTTP client defaults for outbound requests.
    """
    model_config = SettingsConfigDict(env_prefix="HTTP_CLIENT_", frozen=True)

    timeout: float = Field(default=10.0, gt=0)
    connect_timeout: float = Field(default=2.0, gt=0)
    retries: int = Field(default=2, ge=0, le=10)
    pool_connections: int = Field(default=10, ge=1)
    pool_maxsize: int = Field(default=20, ge=1)

    @field_validator("connect_timeout")
    @classmethod
    def check_connect_timeout(cls, v: float, info):
        if v > info.data.get("timeout", 10):
            raise ValueError("connect_timeout cannot exceed timeout")
        return v
