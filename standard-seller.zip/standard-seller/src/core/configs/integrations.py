"""
Integrations configurations for service-to-service communication.
"""

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict


class IAMServiceSettings(BaseSettings):
    """
    IAM (Identity and Access Management) service configuration.
    """

    model_config = SettingsConfigDict(env_prefix="IAM_", frozen=True)

    base_url: str = Field(default="http://namuna-iam-api:8000")
    token_path: str = Field(default="/oauth/token")
    client_id: str
    client_secret: str
    audience: Optional[str] = None
    scope: Optional[str] = None
    refresh_skew_seconds: float = Field(default=30.0, ge=0)


class IntegrationsSettings(BaseSettings):
    """
    All integrations configuration container.

    Groups configurations for all external service integrations
    used by the application.
    """

    iam: IAMServiceSettings = Field(default_factory=IAMServiceSettings)
