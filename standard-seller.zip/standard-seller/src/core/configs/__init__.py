"""
Application settings
"""

from pydantic import Field

from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict

from src.core.configs.jwt import JWTSettings
from src.core.configs.pagination import PaginationSettings
from src.core.configs.http_client import HTTPClientSettings
from src.core.configs.database import PostgresDatabaseSettings
from src.core.configs.integrations import IntegrationsSettings


class Settings(BaseSettings):
    """
    Main application settings.
    Combines all sub-settings into a single object.
    """
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        frozen=True
    )

    jwt: JWTSettings = Field(default_factory=JWTSettings)
    pagination: PaginationSettings = Field(default_factory=PaginationSettings)
    http_client: HTTPClientSettings = Field(default_factory=HTTPClientSettings)
    integrations: IntegrationsSettings = Field(default_factory=IntegrationsSettings)
    postgres: PostgresDatabaseSettings = Field(default_factory=PostgresDatabaseSettings)


settings = Settings()
