"""
JWT configurations
"""

from pydantic import Field
from pydantic_settings import BaseSettings
from pydantic_settings import SettingsConfigDict


class JWTSettings(BaseSettings):
    """
    JWT / Auth configuration.
    """
    model_config = SettingsConfigDict(env_prefix="JWT_", frozen=True)

    jwks_url: str = "http://iam-service:8000/.well-known/jwks.json"
    issuer: str = "http://iam-service:8000"
    audience: str = "namuna-api"
    algorithm: str = "RS256"
    clock_skew_seconds: int = Field(default=60, ge=0, le=300)
    jwks_cache_ttl: int = Field(default=300, ge=60, le=3600)
    roles_claim: str = "roles"
    refresh_token_expire_days: int = Field(default=30, ge=1, le=365)
