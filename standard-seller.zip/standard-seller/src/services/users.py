"""
API for User persistence and retrieval.
"""

from uuid import UUID

from src.enums.sorting import SortOrder
from src.services.base import BaseService

from src.schemas.users import UserReadSchema
from src.schemas.users import UserCreateSchema
from src.schemas.users import UserUpdateSchema
from src.schemas.pagination import PaginatedResponseSchema

from src.exceptions.service.users import UserAlreadyExists
from src.exceptions.service.users import user_service_exceptions


class UsersService(BaseService):
    """
    Service class for CRUD operations on users with simple integer IDs.
    Only handles email and password fields without any authentication logic.
    """

    @user_service_exceptions
    async def get_one_by_id(self, user_id: UUID) -> UserReadSchema:
        """
        Retrieve a single user by their UUID.

        :param user_id: UUID of the user to retrieve
        :return: UserReadSchema representing the retrieved user
        :raises UserNotFound: If no user exists with the given UUID
        """
        user = await self.db.users.get_one(id=user_id)
        return user

    @user_service_exceptions
    async def get_by_email(self, email: str) -> UserReadSchema:
        """
        Retrieve a single user by their email address.

        :param email: Email of the user to retrieve
        :return: UserReadSchema representing the retrieved user
        :raises UserNotFound: If no user exists with the given email
        """
        user = await self.db.users.get_one(email=email)
        return UserReadSchema(**user)

    @user_service_exceptions
    async def get_list(
        self,
        limit: int = 10,
        offset: int = 0,
        current_page: int = 1,
        sort_field: str | None = None,
        sort_order: SortOrder = SortOrder.DESC,
    ) -> PaginatedResponseSchema[UserReadSchema]:
        """
        Retrieve a paginated list of users.

        :param limit: Number of users per page (default: 10)
        :param offset: Number of users to skip (default: 0)
        :param current_page: Current page number (default: 1)
        :param sort_field: Optional field name to sort by
        :param sort_order: Sorting direction (asc or desc)
        :return: PaginatedResponseSchema containing list of users and metadata
        """
        items = await self.db.users.get_all(
            limit=limit,
            offset=offset,
            sort_field=sort_field,
            sort_order=sort_order,
        )
        total_items = await self.db.users.count()
        return self.build_paginated_response(
            items=items,
            total_items=total_items,
            current_page=current_page,
            per_page=limit,
            message="Users retrieved successfully",
        )

    @user_service_exceptions
    async def create(self, data: UserCreateSchema) -> UserReadSchema:
        """
        Create a new user.

        :param data: UserCreateSchema containing user creation data
        :return: UserReadSchema representing the newly created user
        """
        existing = await self.db.users.get_one_or_none(email=data.email)
        if existing:
            raise UserAlreadyExists(f"User with email {data.email} already exists")
        user = await self.db.users.add(data)
        await self.db.commit()
        return user

    @user_service_exceptions
    async def update(self, user_id: UUID, data: UserUpdateSchema) -> UserReadSchema:
        """
        Update an existing user.

        :param user_id: UUID of the user to update
        :param data: UserUpdateSchema containing fields to update
        :return: UserReadSchema representing the updated user
        """
        user = await self.db.users.update_one(id=user_id, data=data, partially=True)
        await self.db.commit()
        return user

    @user_service_exceptions
    async def delete(self, user_id: UUID) -> int:
        """
        Delete a user by UUID.

        :param user_id: UUID of the user to delete
        :return: ID of the deleted user
        """
        user = await self.db.users.delete_one(id=user_id)
        await self.db.commit()
        return user.id
