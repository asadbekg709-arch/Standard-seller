"""
Enums for endpoints.
"""

from enum import Enum


class ActorType(str, Enum):
    user = "user"
    service = "service"
