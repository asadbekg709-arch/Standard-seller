"""
Enums for sorting.
"""

from enum import Enum


class SortOrder(str, Enum):
    ASC = "asc"
    DESC = "desc"
  