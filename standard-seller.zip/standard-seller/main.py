def main():
    print("Hello from standard-seller!")


if __name__ == "__main__":
    main()
