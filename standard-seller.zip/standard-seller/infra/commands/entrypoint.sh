#!/bin/bash
set -e

echo "Waiting for postgres..."
while ! pg_isready -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -q; do
  sleep 1
done
echo "PostgreSQL is up - executing command"

echo "Applying database migrations..."
uv run alembic upgrade head
echo "Migrations applied successfully."

exec "$@"
